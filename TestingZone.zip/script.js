var phrase = "funny"

function gavinO(){
  let prom = prompt("guess the phrase (can literally be anything)")
  if (prom == phrase){
    alert("you got it")
  }
}